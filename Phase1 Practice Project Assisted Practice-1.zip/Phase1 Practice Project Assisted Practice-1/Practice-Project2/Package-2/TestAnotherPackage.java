package pack1;

import JavaFSD.*;

public class TestAnotherPackage {
public static void main(String [] args) {
		
		AccessModifier obj= new  AccessModifier();
		
		
		///public method is a globally accessible to all classes and packages
		//obj.methodDefault();
		//obj.methodPrivate();
		//obj.methodProtected();
		obj.methodPublic();
			
		
	}

}
